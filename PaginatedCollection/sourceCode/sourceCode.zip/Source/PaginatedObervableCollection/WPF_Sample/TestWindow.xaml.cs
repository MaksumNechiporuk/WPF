﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace PaginatedObervableCollection
{

    public class DummyData
    {
        public string Name { get; set; }
        public int Value { get; set; }
    }



    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class TestWindow : Window
    {
        PaginatedObservableCollection<DummyData> paginatedCollection = new PaginatedObservableCollection<DummyData>(3);

        public TestWindow()
        {
            InitializeComponent();
            paginatedCollection.Add(new DummyData() { Name="ONE" , Value= 01 });
            paginatedCollection.Add(new DummyData() { Name = "TWO", Value = 02 });
            paginatedCollection.Add(new DummyData() { Name = "THREE", Value = 03 });
            paginatedCollection.Add(new DummyData() { Name = "FOUR", Value = 04 });
            paginatedCollection.Add(new DummyData() { Name = "FIVE", Value = 05 });
            paginatedCollection.Add(new DummyData() { Name = "SIX", Value = 06 });
            paginatedCollection.Add(new DummyData() { Name = "SEVEN", Value = 07 });
            paginatedCollection.Add(new DummyData() { Name = "EIGHT", Value = 08 });
            paginatedCollection.Add(new DummyData() { Name = "NINE", Value = 09 });
            paginatedCollection.Add(new DummyData() { Name = "TEN", Value = 10 });
            paginatedCollection.Add(new DummyData() { Name = "ELEVEN", Value = 11 });
            paginatedCollection.Add(new DummyData() { Name = "TWELVE", Value = 12 });
            paginatedCollection.Add(new DummyData() { Name = "THIRTEEN", Value = 13 });
            paginatedCollection.Add(new DummyData() { Name = "FOURTEEN", Value = 14 });
            paginatedCollection.Add(new DummyData() { Name = "FIFTEEN", Value = 15 });
            paginatedCollection.Add(new DummyData() { Name = "SIXTEEN", Value = 16 });
            paginatedCollection.Add(new DummyData() { Name = "SEVETEEN", Value = 17 });
            paginatedCollection.Add(new DummyData() { Name = "EIGHTEEN", Value = 18 });
            paginatedCollection.Add(new DummyData() { Name = "NINETEEN", Value = 19 });
            paginatedCollection.Add(new DummyData() { Name = "TWENTY", Value = 20 });
            paginatedCollection.Add(new DummyData() { Name = "TWENTYONE", Value = 21 });

            rootVisual.DataContext = paginatedCollection;

            btnNext.Click += new RoutedEventHandler(btnNext_Click);
            btnBack.Click += new RoutedEventHandler(btnBack_Click);
            slider1.ValueChanged += new RoutedPropertyChangedEventHandler<double>(slider1_ValueChanged);

        }

        void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            paginatedCollection.PageSize =  Convert.ToInt32(slider1.Value);
        }

        void btnBack_Click(object sender, RoutedEventArgs e)
        {
            paginatedCollection.CurrentPage = paginatedCollection.CurrentPage - 1;
        }

        void btnNext_Click(object sender, RoutedEventArgs e)
        {
            paginatedCollection.CurrentPage = paginatedCollection.CurrentPage + 1;
        }

    }
}
