**Project Description**
PaginatedObservableCollection can be used at places where you wanted to show data in a paginated manner.  This is a special ObservableCollection which keeps the original collection inside and always exposes a subset of the collection based on some properties
![](Home_paginated.jpg)

More details can be found in the blog - [http://jobijoy.blogspot.com/2008/12/paginated-observablecollection.html](http://jobijoy.blogspot.com/2008/12/paginated-observablecollection.html)
A running silverlight demo is also can be seen in the blog

* the code is not tested against multi threaded scenarios